# Andrei Kaliuzhny — Portfolio

Static portfolio site for GitHub Pages. No build tooling required.

## Preview locally
Open `index.html` in a browser, or run `python -m http.server 8000` from this folder and visit `http://localhost:8000`.

## Publish
1. Create a public GitHub repository called `portfolio`.
2. Upload the **contents** of this folder (not the enclosing folder or ZIP) to the repository root.
3. Go to **Settings → Pages → Build and deployment**.
4. Choose **Deploy from a branch** and select **main**, folder **/(root)**. Save.
5. The site will appear at `https://YOUR-USERNAME.github.io/portfolio/` after deployment.

All paths are relative and work at a GitHub Pages repository subpath.

## Notes
The visuals are exports of the supplied portfolio PDF, provided as placeholder case-gallery assets until original Figma/image exports are available. Please review confidentiality and publication permission for each client project before making the repository public.
